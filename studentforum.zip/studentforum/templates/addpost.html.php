<h2>Ask a Question</h2>

<?php if (!empty($errors)): ?>
    <div class="alert error">
        <?= implode("<br>", $errors) ?>
    </div>
<?php endif; ?>

<?php if (!empty($success)): ?>
    <div class="alert success">
        <?= $success ?>
    </div>
<?php endif; ?>

<form action="addpost.php" method="POST" enctype="multipart/form-data" class="ask-form">
    <label for="postText">Question:</label>
    <textarea name="postText" id="postText" required></textarea>

    <label for="moduleId">Select Module:</label>
    <select name="moduleId" id="moduleId" required>
        <option value="">-- Choose a category --</option>
        <?php foreach ($modules as $module): ?>
            <option value="<?= $module['id'] ?>"><?= htmlspecialchars($module['moduleName']) ?></option>
        <?php endforeach; ?>
    </select>

    <label for="image">Upload Image (optional):</label>
    <input type="file" name="image" id="image">

    <button type="submit" class="btn primary">Post Question</button>
</form>


<a href="index.php" class="btn">Back to Questions</a>
