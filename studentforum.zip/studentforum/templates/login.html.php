<h2>Login</h2>

<?php if (!empty($error)): ?>
    <p class="error"><?= $error ?></p>
<?php endif; ?>

<form action="login.php" method="POST">
    <input type="email" name="email" placeholder="Email" required>
    <input type="password" name="password" placeholder="Password" required>
    <button type="submit" class="btn primary">Log in</button>
</form>

<p>Don't have an account? <a href="register.php">Register</a></p>
