<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?? "Admin Dashboard" ?></title>
    <link rel="stylesheet" href="../css/admin.css">
</head>
<body>

<header class="admin-header">
    <h1>Student Forum - Admin Panel</h1>
    <div class="admin-logout">
        <span>Welcome, <?= htmlspecialchars($_SESSION['username'] ?? 'Admin') ?></span>
        <a href="../public/logout.php" class="btn danger">Log out</a>
    </div>
</header>

<div class="admin-container">
    <aside class="admin-sidebar">
        <ul>
            <li><a href="manage_users.php">👤 Manage Users</a></li>
            <li><a href="manage_modules.php">📚 Manage Modules</a></li>
            <li><a href="manage_posts.php">📝 Manage Posts</a></li>
        </ul>
    </aside>

    <main class="admin-main">
        <?= $content ?? "" ?>
    </main>
</div>

<footer class="admin-footer">
    &copy; Student Forum 2025
</footer>

</body>
</html>
