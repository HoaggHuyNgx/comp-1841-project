<h2>Contact Us</h2>

<?php if ($feedback): ?>
    <p><strong><?= $feedback ?></strong></p>
<?php endif; ?>

<form method="POST" action="contact.php" class="form">
    <label for="name">Your Name:</label>
    <input type="text" name="name" required>

    <label for="email">Your Email:</label>
    <input type="email" name="email" required>

    <label for="subject">Subject:</label>
    <input type="text" name="subject" required>

    <label for="message">Message:</label>
    <textarea name="message" rows="6" required></textarea>

    <button type="submit" class="btn primary">Send Message</button>
</form>
