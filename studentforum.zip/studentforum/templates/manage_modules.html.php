<h2>Manage Modules</h2>

<?php if (!empty($success)): ?>
    <div class="alert success"><?= htmlspecialchars($success) ?></div>
<?php endif; ?>

<?php if (!empty($error)): ?>
    <div class="alert error"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<!-- Form add module-->
<form method="POST" class="ask-form">
    <label for="new_module_name">New Module Name:</label>
    <input type="text" name="new_module_name" id="new_module_name" required>
    <button type="submit" class="btn primary">Add Module</button>
</form>

<!-- List of modules -->
<table class="admin-table">
    <thead>
        <tr>
            <th>ID</th>
            <th>Module Name</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($modules as $module): ?>
            <tr>
                <td><?= htmlspecialchars($module['id']) ?></td>
                <td>
                    <!-- Direct editing form for each module -->
                    <form method="POST" style="display:flex; gap:5px;">
                        <input type="hidden" name="edit_module_id" value="<?= $module['id'] ?>">
                        <input type="text" name="edit_module_name" value="<?= htmlspecialchars($module['moduleName']) ?>" required style="width: 150px;">
                        <button type="submit" class="btn primary" style="padding:5px 10px;">Update</button>
                    </form>
                </td>
                <td>
                    <a href="manage_modules.php?delete=<?= $module['id'] ?>" class="btn danger" onclick="return confirm('Are you sure you want to delete this module?')">
                        Delete
                    </a>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
