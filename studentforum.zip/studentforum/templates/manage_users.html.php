<h2>Manage Users</h2>
<div style="text-align: right; margin-bottom: 20px;">
    <a href="add_user.php" class="btn primary">+ Add New User</a>
</div>
<table class="admin-table">
    <thead>
        <tr>
            <th>ID</th>
            <th>Username</th>
            <th>Email</th>
            <th>Role</th>
            <th>Created At</th>
            <th style="text-align: center;">Action</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($users as $user): ?>
            <tr>
                <td><?= htmlspecialchars($user['id']) ?></td>
                <td><?= htmlspecialchars($user['username']) ?></td>
                <td><?= htmlspecialchars($user['email']) ?></td>
                <td><?= htmlspecialchars($user['role']) ?></td>
                <td><?= htmlspecialchars($user['created_at']) ?></td>
                <td style="text-align: center;">
                    <?php if ($user['role'] !== 'admin'): ?>
                        <form action="manage_users.php" method="GET" style="display:inline-block;">
                            <input type="hidden" name="delete" value="<?= $user['id'] ?>">
                            <button type="submit" onclick="return confirm('Are you sure to delete this user?');" class="btn danger">Delete</button>
                            <a href="edit_user.php?id=<?= $user['id'] ?>" class="btn">Edit</a>
                        </form>
                    <?php else: ?>
                        <span class="protected">Protected</span>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
