<?php if (!empty($error)): ?>
    <div class="alert error">
        <?= $error ?>
    </div>
<?php endif; ?>
