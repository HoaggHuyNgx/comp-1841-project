<h2>Filter Questions by Module</h2>

<form method="POST" action="filter.php" class="ask-form">
    <label for="moduleId">Select Module:</label>
    <select name="moduleId" id="moduleId" required>
        <option value="">-- Choose a module --</option>
        <?php foreach ($modules as $module): ?>
            <option value="<?= $module['id'] ?>"><?= htmlspecialchars($module['moduleName']) ?></option>
        <?php endforeach; ?>
    </select>
    <button type="submit" class="btn primary">Apply Filter</button>
</form>

<?php if (!empty($filteredPosts)): ?>
    <h3>Filtered Results:</h3>
    <div class="post-container">
        <?php foreach ($filteredPosts as $post): ?>
            <div class="post">
                <img src="../uploads/<?= $post['image'] ?? 'default.png' ?>" alt="img">
                <div class="post-content">
                    <h3><a href="viewpost.php?id=<?= $post['id'] ?>"><?= htmlspecialchars($post['postText']) ?></a></h3>
                    <p><?= htmlspecialchars($post['postText']) ?></p>
                    <p class="post-meta">
                        <strong>Module:</strong> <?= htmlspecialchars($post['moduleName']) ?> |
                        <strong>poster:</strong> <?= htmlspecialchars($post['username']) ?> |
                        <strong>Day:</strong> <?= $post['postDate'] ?>
                    </p>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php elseif ($_SERVER["REQUEST_METHOD"] === "POST"): ?>
    <p>No posts found for the selected module.</p>
<?php endif; ?>
