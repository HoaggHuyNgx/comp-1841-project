<h2>Newest Questions</h2>
<p><?= number_format($totalQuestions) ?> questions</p>

<div class="top-buttons">
    <a href="addpost.php" class="btn primary">Ask Question</a>
    <a href="filter.php" class="btn">Filter</a>
</div>

<div class="post-container">
    <?php foreach ($posts as $post): ?>
        <div class="post">
            <img src="../uploads/<?= htmlspecialchars($post['image'] ?? 'default.png') ?>" alt="Post Image">
            <div class="post-content">
                <h3>
                    <a href="viewpost.php?id=<?= $post['id'] ?>">
                        <?= htmlspecialchars($post['postText']) ?>
                    </a>
                </h3>
                <p><?= htmlspecialchars($post['postText']) ?></p>
                <p class="post-meta">
                    <strong>Module:</strong> <?= htmlspecialchars($post['moduleName'] ?? 'Unknown') ?> |
                    <strong>Poster:</strong> <?= htmlspecialchars($post['username']) ?> |
                    <strong>Day:</strong> <?= htmlspecialchars($post['postDate']) ?>
                </p>
            </div>
        </div>
    <?php endforeach; ?>
</div>
