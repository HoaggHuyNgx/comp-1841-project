<h2>Edit Post</h2>

<?php if (!empty($errors)): ?>
    <div class="alert error">
        <?= implode("<br>", $errors) ?>
    </div>
<?php endif; ?>

<?php if (!empty($success)): ?>
    <div class="alert success">
        <?= $success ?>
    </div>
<?php endif; ?>

<form action="editpost.php?id=<?= $post['id'] ?>" method="POST" enctype="multipart/form-data">
    <label for="postText">Question:</label>
    <textarea name="postText" id="postText" required><?= htmlspecialchars($post['postText']) ?></textarea>

    <label for="moduleId">Select Module:</label>
    <select name="moduleId" id="moduleId" required>
        <option value="">-- Choose a category --</option>
        <?php foreach ($modules as $module): ?>
            <option value="<?= $module['id'] ?>" <?= $module['id'] == $post['moduleId'] ? 'selected' : '' ?>><?= htmlspecialchars($module['moduleName']) ?></option>
        <?php endforeach; ?>
    </select>

    <label for="image">Upload Image (optional):</label>
    <input type="file" name="image" id="image">

    <button type="submit" class="btn primary">Update Question</button>
</form>

<a href="index.php" class="btn">Back to Questions</a>
