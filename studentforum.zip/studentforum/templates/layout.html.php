<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?? "Student Forum" ?></title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>

<!-- 📌 Header -->
<header class="header">
    <div class="header-left">
        <h1 class="logo">Student Forum</h1>
        <nav>
            <a href="#">About</a>
            <a href="contact.php">Contact us</a>
            <a href="login.php">Admin Login</a>
        </nav>
    </div>
    <div class="header-center">
        <form action="search.php" method="GET" class="search-form">
            <input type="text" name="keyword" placeholder="Search Questions" required>
        </form>
    </div>
    <div class="header-right">
        <?php if (isset($_SESSION['user_id'])): ?>
            <span>Welcome, <?= htmlspecialchars($_SESSION['username']) ?></span>
            <a href="logout.php" class="btn">Log out</a>
        <?php else: ?>
            <a href="login.php" class="login-btn">Log in</a>
            <a href="register.php" class="signup-btn">Sign up</a>
        <?php endif; ?>
    </div>
</header>

<!-- Layout-->
<div class="container">
    <!-- Sidebar -->
    <aside class="sidebar">
        <ul>
            <li><a href="index.php">🏠 Home</a></li>
            <li><a href="question.php">❓ Questions</a></li>
        </ul>
    </aside>

    <!-- Main content -->
    <main class="main-content">
        <?= $content ?? "" ?>
    </main>
</div>

<!-- Footer -->
<footer class="footer">
    &copy; Student Forum <?= date('Y') ?>
</footer>

</body>
</html>
