<div class="admin-main">
    <h2>Add New User</h2>

    <?php if (!empty($error)): ?>
        <div class="alert error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form action="add_user.php" method="post" class="ask-form">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>

        <button type="submit" class="btn primary">Add User</button>
    </form>
</div>
