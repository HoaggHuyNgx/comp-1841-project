<h2>Manage Posts</h2>

<?php if (isset($success)): ?>
    <div class="alert success"><?= htmlspecialchars($success) ?></div>
<?php endif; ?>

<?php if (isset($error)): ?>
    <div class="alert error"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<table class="admin-table">
    <thead>
        <tr>
            <th>ID</th>
            <th>Question</th>
            <th>Module</th>
            <th>Author</th>
            <th>Posted At</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php if (!empty($posts)): ?>
            <?php foreach ($posts as $post): ?>
                <tr>
                <td><?= htmlspecialchars($post['id']) ?></td>
                <td><?= htmlspecialchars(substr($post['postText'], 0, 50)) ?>...</td>
                <td><?= htmlspecialchars($post['moduleName'] ?? 'Unknown') ?></td>
                <td><?= htmlspecialchars($post['username']) ?></td>
                <td><?= htmlspecialchars($post['postDate']) ?></td>
                    <td>
                        <a href="manage_posts.php?delete=<?= $post['id'] ?>" 
                           class="btn danger"
                           onclick="return confirm('Are you sure you want to delete this post?')">
                           Delete
                        </a>
                        <a href="../public/editpost.php?id=<?= $post['id'] ?>" class="btn primary">Edit</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td colspan="6">No posts found.</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>
