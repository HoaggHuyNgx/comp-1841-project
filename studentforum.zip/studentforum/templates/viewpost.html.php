<h2><?= htmlspecialchars($post['postText']) ?></h2>

<!-- Show image if available -->
<?php if (!empty($post['image'])): ?>
    <img src="../uploads/<?= htmlspecialchars($post['image']) ?>" alt="Post Image" class="post-image">
<?php endif; ?>

<p class="post-meta">
    <strong>Module:</strong> <?= htmlspecialchars($post['modulename']) ?> |
    <strong>Poster:</strong> <?= htmlspecialchars($post['username']) ?> |
    <strong>Day:</strong> <?= $post['postDate'] ?>
</p>

<p class="post-content"><?= nl2br(htmlspecialchars($post['postText'])) ?></p>

<h3>Comments</h3>
<div class="comments-section">
    <?php if (!empty($comments)): ?>
        <?php foreach ($comments as $comment): ?>
            <div class="comment">
                <strong><?= htmlspecialchars($comment['username']) ?>:</strong>
                <p><?= nl2br(htmlspecialchars($comment['commentText'])) ?></p>
                <span class="comment-date"><?= $comment['commentDate'] ?></span>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p>No comments yet.</p>
    <?php endif; ?>
</div>

<!-- Form for users to enter comments -->
<?php if (isset($_SESSION['user_id'])): ?>
    <form action="viewpost.php?id=<?= $postId ?>" method="POST">
        <textarea name="commentText" placeholder="Write a comment..." required></textarea>
        <button type="submit" class="btn primary">Post Comment</button>
    </form>
<?php else: ?>
    <p><a href="login.php">Log in</a> to comment.</p>
<?php endif; ?>

<!-- Edit and Delete post function for Admin and post owner -->
<?php if (isset($_SESSION['user_id'])): ?>
    <?php $userId = $_SESSION['user_id']; ?>
    <?php if ($_SESSION['role'] == 'admin' || $post['userId'] == $userId): ?>
        <a href="editpost.php?id=<?= $postId ?>" class="btn primary">Edit Post</a>
        <a href="deletepost.php?id=<?= $postId ?>" class="btn danger" onclick="return confirm('Are you sure you want to delete this post?')">Delete Post</a>
    <?php endif; ?>
<?php endif; ?>

<a href="index.php" class="btn">Back to Questions</a>
