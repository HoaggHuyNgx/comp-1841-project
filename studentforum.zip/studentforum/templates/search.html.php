<h2>Search Results for "<?= htmlspecialchars($keyword) ?>"</h2>

<?php if (!empty($results)): ?>
    <div class="post-container">
        <?php foreach ($results as $post): ?>
            <div class="post">
                <img src="../uploads/<?= $post['image'] ?? 'default.png' ?>" alt="Post Image">
                <div class="post-content">
                    <h3><a href="viewpost.php?id=<?= $post['id'] ?>"><?= htmlspecialchars($post['postText']) ?></a></h3>
                    <p><?= htmlspecialchars($post['postText']) ?></p>
                    <p class="post-meta">
                        <strong>Module:</strong> <?= htmlspecialchars($post['moduleName']) ?> |
                        <strong>Poster:</strong> <?= htmlspecialchars($post['username']) ?> |
                        <strong>Day:</strong> <?= $post['postDate'] ?>
                    </p>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php else: ?>
    <p>No results found.</p>
<?php endif; ?>
