<h2>Edit User</h2>

<?php if ($success): ?>
    <div class="alert success"><?= $success ?></div>
<?php endif; ?>

<?php foreach ($errors as $error): ?>
    <div class="alert error"><?= $error ?></div>
<?php endforeach; ?>

<form method="POST">
    <label>Username:</label>
    <input type="text" name="username" value="<?= htmlspecialchars($user['username']) ?>" required>

    <label>Email:</label>
    <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>

    <label>Role:</label>
    <select name="role">
        <option value="user" <?= $user['role'] === 'user' ? 'selected' : '' ?>>User</option>
        <option value="admin" <?= $user['role'] === 'admin' ? 'selected' : '' ?>>Admin</option>
    </select>

    <button type="submit" class="btn primary">Update User</button>
</form>
