<?php
require_once '../includes/DatabaseConnection.php';
require_once '../includes/Session.php';
require_once '../includes/Databasefunctions.php';

requireLogin();

$errors = [];
$success = "";

// Process when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $postText = trim($_POST['postText'] ?? '');
    $moduleId = $_POST['moduleId'] ?? '';
    $userId = $_SESSION['user_id'];

    // Call the image upload function
    [$imageName, $uploadError] = handleImageUpload();

    // Log error if upload fails
    if ($uploadError) {
        $errors[] = $uploadError;
    }

    // Validate post content
    if (empty($postText)) {
        $errors[] = "Please enter question content.";
    }
    if (empty($moduleId)) {
        $errors[] = "Please select a category.";
    }

    // If there are no errors, proceed to add the post
    if (empty($errors)) {
        if (addPost($pdo, $userId, $moduleId, $postText, $imageName)) {
            $success = "Question posted successfully!";
        } else {
            $errors[] = "Error posting.";
        }
    }
}

// Get list of modules from database to load into form
$modules = getAllModules($pdo);
$title = "Ask a Question";

// Render interface
ob_start();
include '../templates/addpost.html.php';
$content = ob_get_clean();
include '../templates/layout.html.php';
?>
