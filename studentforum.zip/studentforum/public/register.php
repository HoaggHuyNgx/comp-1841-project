<?php
require_once '../includes/DatabaseConnection.php';
require_once '../includes/Session.php';
require_once '../includes/Databasefunctions.php';

$title = "Register";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirm_password'];

    if ($password !== $confirmPassword) {
        $error = "Passwords do not match!";
    } else {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        if (registerUser($pdo, $username, $email, $hashedPassword)) {
            header("Location: login.php");
            exit();
        } else {
            $error = "Registration failed. Username or email might be taken.";
        }
    }
}

ob_start();
include '../templates/register.html.php';
$content = ob_get_clean();
include '../templates/layout.html.php';
?>
