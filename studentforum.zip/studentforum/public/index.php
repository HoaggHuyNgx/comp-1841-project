<?php
require_once '../includes/DatabaseConnection.php';
require_once '../includes/Session.php';
require_once '../includes/Databasefunctions.php';

$title = "Student Forum";

ob_start();
include '../templates/home.html.php'; 
$content = ob_get_clean();
include '../templates/layout.html.php';
