<?php
require_once '../includes/DatabaseConnection.php';
require_once '../includes/Session.php';    
require_once '../includes/Databasefunctions.php';  

$title = "Filter Questions";

// Filter processing
$filteredPosts = [];
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $moduleId = $_POST['moduleId'] ?? '';

    if (!empty($moduleId)) {
        $filteredPosts = filterPostsByModule($pdo, $moduleId);
    }
}

// Get the list of modules to display the dropdown
$modules = getAllModules($pdo);

ob_start();
include '../templates/filter.html.php';
$content = ob_get_clean();
include '../templates/layout.html.php';
?>
