<?php
require_once '../includes/DatabaseConnection.php';
require_once '../includes/Session.php';
require_once '../includes/Databasefunctions.php';

requireLogin();

$error = "";

//Check if post ID is passed in
if (isset($_GET['id'])) {
    $postId = $_GET['id'];
    $post = getPostById($pdo, $postId);

    if (!$post) {
        header("Location: index.php");
        exit();
    }

    //Check deletion permissions
    if ($post['userId'] == $_SESSION['user_id'] || isAdmin()) {
        if (deletePost($pdo, $postId)) {
            header("Location: index.php");
            exit();
        } else {
            $error = "Error deleting post.";
        }
    } else {
        $error = "You do not have permission to delete this post.";
    }
} else {
    header("Location: index.php");
    exit();
}

//If there is an error, display a simple error
$title = "Delete Post Error";
ob_start();
?>
<div class="alert error"><?= htmlspecialchars($error) ?></div>
<a href="index.php" class="btn">Back to Questions</a>
<?php
$content = ob_get_clean();
include '../templates/layout.html.php';
?>
