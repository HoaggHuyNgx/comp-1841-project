<?php
require_once '../includes/DatabaseConnection.php';
require_once '../includes/Session.php';
require_once '../includes/Databasefunctions.php';

requireLogin();

$errors = [];
$success = "";

//Get article information by ID
if (isset($_GET['id'])) {
    $postId = (int) $_GET['id'];
    $post = getPostById($pdo, $postId);

    if (!$post) {
        header('Location: index.php');
        exit();
    }

    //Check editing rights: Admin or topic owner
    if ($_SESSION['role'] !== 'admin' && $_SESSION['user_id'] != $post['userId']) {
        $errors[] = "You do not have permission to edit this article.";
    }
} else {
    header('Location: index.php');
    exit();
}

//Process form submission
if ($_SERVER["REQUEST_METHOD"] === "POST" && empty($errors)) {
    $postText = trim($_POST['postText'] ?? '');
    $moduleId = $_POST['moduleId'] ?? '';
    $imageName = $post['image'];

    //If uploading new image
    if (!empty($_FILES['image']['name'])) {
        [$newImageName, $uploadError] = handleImageUpload();

        if ($uploadError) {
            $errors[] = $uploadError;
        } else {
            $imageName = $newImageName;
        }
    }

    //Validate
    if (empty($postText)) {
        $errors[] = "Please enter question content.";
    }
    if (empty($moduleId)) {
        $errors[] = "Please select a category.";
    }

    //If there is no error, proceed with the update
    if (empty($errors)) {
        if (updatePost($pdo, $postId, $postText, $moduleId, $imageName)) {
            $success = "Post updated successfully!";
            //Reload post data after update
            $post = getPostById($pdo, $postId);
        } else {
            $errors[] = "Error updating post.";
        }
    }
}

//Load module list for dropdown
$modules = getAllModules($pdo);

//Set title
$title = "Edit Post";

ob_start();
include '../templates/editpost.html.php';
$content = ob_get_clean();
include '../templates/layout.html.php';
?>
