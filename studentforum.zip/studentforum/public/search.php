<?php
require_once '../includes/DatabaseConnection.php';
require_once '../includes/Session.php';    
require_once '../includes/Databasefunctions.php';  

$title = "Search Results";

$keyword = trim($_GET['keyword'] ?? '');
$results = [];

if (!empty($keyword)) {
    $results = searchPosts($pdo, $keyword);
}

ob_start();
include '../templates/search.html.php';
$content = ob_get_clean();
include '../templates/layout.html.php';
?>
