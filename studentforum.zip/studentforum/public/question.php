<?php
require_once '../includes/DatabaseConnection.php';
require_once '../includes/Databasefunctions.php';
require_once '../includes/Session.php';

try {
    $posts = getAllPosts($pdo);

    $totalQuestions = count($posts);

    $title = "Newest Questions";

    ob_start();

    include '../templates/questions.html.php';
    $content = ob_get_clean();

    include '../templates/layout.html.php';

} catch (PDOException $e) {
    $title = 'An error has occurred';
    $output = 'Database error: ' . htmlspecialchars($e->getMessage());
    include '../templates/layout.html.php';
}
?>
