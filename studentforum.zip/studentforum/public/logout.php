<?php
require_once '../includes/Session.php';

session_unset();
session_destroy();

header("Location: login.php");
exit();
?>
