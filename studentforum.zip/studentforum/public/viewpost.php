<?php
require_once '../includes/DatabaseConnection.php';
require_once '../includes/Databasefunctions.php';
require_once '../includes/Session.php';

if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("❌ Error: No post found.");
}

$postId = $_GET['id'];
$post = getPostById($pdo, $postId);

if (!$post) {
    die("❌The article does not exist.");
}
// Get list of comments (if any)
$comments = getCommentsByPostId($pdo, $postId);

$title = "View Question";
ob_start();

// Include viewpost.html.php interface file to display post information
include '../templates/viewpost.html.php';

$content = ob_get_clean();
include '../templates/layout.html.php';

//Process when user sends comment
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['commentText'])) {
    $commentText = trim($_POST['commentText']);
    $userId = $_SESSION['user_id'];

    if (!empty($commentText)) {
        addComment($pdo, $postId, $userId, $commentText);
        header("Location: viewpost.php?id=" . $postId);
        exit();
    }
}
?>
