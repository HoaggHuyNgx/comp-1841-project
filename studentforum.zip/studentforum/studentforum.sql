-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th4 29, 2025 lúc 09:06 AM
-- Phiên bản máy phục vụ: 10.4.32-MariaDB
-- Phiên bản PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `studentforum`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `postId` int(11) DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  `commentText` text DEFAULT NULL,
  `commentDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `comments`
--

INSERT INTO `comments` (`id`, `postId`, `userId`, `commentText`, `commentDate`) VALUES
(1, 20, 9, 'cc', '2025-03-21 09:59:40'),
(4, 25, 9, 'cccc', '2025-03-23 15:57:38');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `sender_name` varchar(255) NOT NULL,
  `sender_email` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `messages`
--

INSERT INTO `messages` (`id`, `sender_name`, `sender_email`, `subject`, `message`, `created_at`) VALUES
(1, 'Nguyễn', 'Huyxxx567@gmail.com', '123', 'heloo world\r\n', '2025-04-29 02:04:17');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `modules`
--

CREATE TABLE `modules` (
  `id` int(11) NOT NULL,
  `moduleName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `modules`
--

INSERT INTO `modules` (`id`, `moduleName`) VALUES
(2, 'FULLSNACK'),
(4, 'HISTORY'),
(3, 'MATH'),
(5, 'VOVINAM'),
(1, 'WEB 1');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `postText` text NOT NULL,
  `postDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `moduleId` int(11) DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `posts`
--

INSERT INTO `posts` (`id`, `postText`, `postDate`, `moduleId`, `userId`, `image`) VALUES
(1, 'How to center a div in CSS?', '2025-03-18 09:50:46', 1, 1, 'cc.png'),
(2, 'What is the difference between React and Vue?', '2025-03-18 09:50:46', 2, 2, NULL),
(4, 'Who was the first president of the United States?', '2025-03-18 09:50:46', 4, 4, NULL),
(5, 'What are the basic rules of Vovinam?', '2025-03-18 09:50:46', 5, 5, NULL),
(16, 'How to fix a memory leak in JavaScript?', '2025-03-18 10:00:00', 1, 3, NULL),
(17, 'What are the differences between SQL and NoSQL databases?', '2025-03-18 10:05:00', 2, 5, NULL),
(18, 'Best practices for securing a PHP web application', '2025-03-18 10:10:00', 3, 2, NULL),
(19, 'How does the event loop work in Node.js?', '2025-03-18 10:15:00', 1, 5, NULL),
(20, 'Understanding recursion in programming', '2025-03-18 10:20:00', 2, 1, NULL),
(21, 'What are the key features of Python 3.10?', '2025-03-18 10:25:00', 1, 4, NULL),
(22, 'How to optimize database queries for performance?', '2025-03-18 10:30:00', 2, 3, NULL),
(23, 'What is the difference between synchronous and asynchronous programming?', '2025-03-18 10:35:00', 3, 5, NULL),
(24, 'How to implement authentication in a React app?', '2025-03-18 10:40:00', 3, 2, NULL),
(25, 'Best resources to learn full-stack development?', '2025-03-18 10:45:00', 3, 3, NULL);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('user','admin') DEFAULT 'user',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `role`, `created_at`) VALUES
(1, 'HUY', 'huy@example.com', 'password123', 'admin', '2025-03-18 09:49:06'),
(2, 'LINH', 'linh@example.com', 'password123', 'user', '2025-03-18 09:49:06'),
(3, 'QUAN', 'quan@example.com', 'password123', 'user', '2025-03-18 09:49:06'),
(4, 'ANH', 'anh@example.com', 'password123', 'user', '2025-03-18 09:49:06'),
(5, 'THAO', 'thao@example.com', 'password123', 'user', '2025-03-18 09:49:06'),
(9, 'Trungngu1325', 'Huyxxx567@gmail.com', '123', 'user', '2025-03-21 09:33:50'),
(12, 'hhuy', 'huyhihi@gmail.com', '123', 'user', '2025-03-23 15:58:45'),
(13, 'TraNTL', 'Tra@gmail.com', '$2y$10$JFpPB49LOvAQrshM//0TlORmR4Jdx72rORw7YP/sw1ZkJsENfrZpi', 'user', '2025-04-29 07:02:23');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userId` (`userId`),
  ADD KEY `comments_ibfk_1` (`postId`);

--
-- Chỉ mục cho bảng `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `modules`
--
ALTER TABLE `modules`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `moduleName` (`moduleName`);

--
-- Chỉ mục cho bảng `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `moduleId` (`moduleId`),
  ADD KEY `userId` (`userId`);

--
-- Chỉ mục cho bảng `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT cho bảng `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT cho bảng `modules`
--
ALTER TABLE `modules`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT cho bảng `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT cho bảng `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`postId`) REFERENCES `posts` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `comments_ibfk_2` FOREIGN KEY (`userId`) REFERENCES `users` (`id`);

--
-- Các ràng buộc cho bảng `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `posts_ibfk_1` FOREIGN KEY (`moduleId`) REFERENCES `modules` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `posts_ibfk_2` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
