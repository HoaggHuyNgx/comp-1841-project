<?php
require_once 'DatabaseConnection.php';

// Get a list of all posts from the database
function getAllPosts($pdo) {
    $stmt = $pdo->query("SELECT posts.id, posts.postText, posts.postDate, posts.image,
                                users.username, modules.moduleName
                         FROM posts
                         JOIN users ON posts.userId = users.id
                         JOIN modules ON posts.moduleId = modules.id
                         ORDER BY posts.postDate DESC");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}


// Get list of all modules from database
function getAllModules($pdo) {
    $stmt = $pdo->query("SELECT * FROM modules ORDER BY moduleName ASC");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

//Update module
function updateModule($pdo, $id, $newName) {
    $stmt = $pdo->prepare("UPDATE modules SET moduleName = :moduleName WHERE id = :id");
    return $stmt->execute([
        'moduleName' => $newName,
        'id' => $id
    ]);
}



//Function to add articles to database
function addPost($pdo, $userId, $moduleId, $postText, $image = null) {
    $stmt = $pdo->prepare("INSERT INTO posts (userId, moduleId, postText, postDate, image) VALUES (:userId, :moduleId, :postText, NOW(), :image)");
    return $stmt->execute([
        'userId' => $userId,
        'moduleId' => $moduleId,
        'postText' => $postText,
        'image' => $image
    ]);
}
//Image upload processing function
function handleImageUpload($inputName = 'image', $uploadDir = '../uploads/') {
    $imageName = null;

    if (!empty($_FILES[$inputName]['name'])) {
        $imageName = time() . '_' . basename($_FILES[$inputName]['name']);
        $targetFilePath = $uploadDir . $imageName;

        $imageFileType = strtolower(pathinfo($targetFilePath, PATHINFO_EXTENSION));
        $allowedTypes = ['jpg', 'jpeg', 'png', 'gif'];

        if (!in_array($imageFileType, $allowedTypes)) {
            return [null, "Only JPG, JPEG, PNG, GIF formats are accepted."];
        }

        if (!move_uploaded_file($_FILES[$inputName]["tmp_name"], $targetFilePath)) {
            return [null, "Error uploading image."];
        }
    }

    return [$imageName, null];
}


//Get detailed information of an article
function getPostById($pdo, $id) {
    $stmt = $pdo->prepare("SELECT posts.*, users.username, modules.modulename 
                           FROM posts 
                           JOIN users ON posts.userId = users.id 
                           JOIN modules ON posts.moduleId = modules.id 
                           WHERE posts.id = :id");
    $stmt->execute(['id' => $id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

//Get list of comments by post
function getCommentsByPostId($pdo, $postId) {
    $stmt = $pdo->prepare("SELECT comments.*, users.username 
                           FROM comments 
                           JOIN users ON comments.userId = users.id 
                           WHERE comments.postId = :postId 
                           ORDER BY comments.commentDate DESC");
    $stmt->execute(['postId' => $postId]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

//Add comments to database
function addComment($pdo, $postId, $userId, $commentText) {
    $stmt = $pdo->prepare("INSERT INTO comments (postId, userId, commentText, commentDate) VALUES (:postId, :userId, :commentText, NOW())");
    return $stmt->execute(['postId' => $postId, 'userId' => $userId, 'commentText' => $commentText]);
}

?>
<?php
//Function to get user information by email
function getUserByEmail($pdo, $email) {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = :email");
    $stmt->execute(['email' => $email]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function registerUser($pdo, $username, $email, $password) {
    try {
        $stmt = $pdo->prepare("INSERT INTO users (username, email, password) VALUES (:username, :email, :password)");
        return $stmt->execute([
            'username' => $username,
            'email' => $email,
            'password' => $password
        ]);
    } catch (PDOException $e) {
        return false;
    }
}
//Function to get user information by id


//Update article information
function updatePost($pdo, $postId, $postText, $moduleId, $imageName = null) {
    $sql = "UPDATE posts SET postText = :postText, moduleId = :moduleId";
    
    if ($imageName) {
        $sql .= ", image = :image";
    }

    $sql .= " WHERE id = :postId";

    $stmt = $pdo->prepare($sql);
    
    $params = [
        'postText' => $postText,
        'moduleId' => $moduleId,
        'postId' => $postId
    ];

    if ($imageName) {
        $params['image'] = $imageName;
    }

    return $stmt->execute($params);
}
//delete related comments before deleting the post
function deletePost($pdo, $postId) {
    // Delete comments related to the article
    $stmt = $pdo->prepare("DELETE FROM comments WHERE postId = :postId");
    $stmt->execute(['postId' => $postId]);

    // After deleting comments, delete post
    $stmt = $pdo->prepare("DELETE FROM posts WHERE id = :id");
    return $stmt->execute(['id' => $postId]);
}

?>

<?php
function filterPostsByModule($pdo, $moduleId) {
    $stmt = $pdo->prepare("SELECT posts.id, posts.postText, posts.postDate, users.username, modules.moduleName, posts.image 
                           FROM posts
                           JOIN users ON posts.userId = users.id
                           JOIN modules ON posts.moduleId = modules.id
                           WHERE posts.moduleId = :moduleId
                           ORDER BY posts.postDate DESC");
    $stmt->execute(['moduleId' => $moduleId]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
//search
function searchPosts($pdo, $keyword) {
    $stmt = $pdo->prepare("SELECT posts.id, posts.postText, posts.postDate, users.username, modules.moduleName, posts.image 
                           FROM posts
                           JOIN users ON posts.userId = users.id
                           JOIN modules ON posts.moduleId = modules.id
                           WHERE posts.postText LIKE :keyword
                           ORDER BY posts.postDate DESC");
    $stmt->execute(['keyword' => "%$keyword%"]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

?>


<?php
// Configuration includes PHPMailer
require_once __DIR__ . '/PHPMailer-master/src/PHPMailer.php';
require_once __DIR__ . '/PHPMailer-master/src/SMTP.php';
require_once __DIR__ . '/PHPMailer-master/src/Exception.php';

// Using the PHPMailer namespace
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Function to handle sending email and saving message to database
function handleContactSubmission($pdo, $name, $email, $subject, $message) {
    // Save to database
    $created_at = date('Y-m-d H:i:s');
    $stmt = $pdo->prepare("INSERT INTO messages (sender_name, sender_email, subject, message, created_at) 
                           VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$name, $email, $subject, $message, $created_at]);

    // Configure PHPMailer
    $mail = new PHPMailer(true);
    try {
        // Configure SMTP for PHPMailer
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'userstudentforum@gmail.com';
        $mail->Password = 'mbiy kcbj wxpc wdju';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        // Configure sender and receiver information
        $mail->setFrom($email, $name);
        $mail->addAddress('huynhgcs220405@fpt.edu.vn');

        //Email content
        $mail->isHTML(true);
        $mail->Subject = "Contact Form: $subject";
        $mail->Body    = "<strong>Name:</strong> $name <br><strong>Email:</strong> $email <br><strong>Subject:</strong> $subject <br><br><strong>Message:</strong><br> $message";

        //Send email
        if ($mail->send()) {
            return true;
        } else {
            return false;
        }
    } catch (Exception $e) {
        // Nếu có lỗi
        error_log("Mailer Error: " . $mail->ErrorInfo);
        return false;
    }
}
?>

<?php
//Get a list of all users
function getAllUsers($pdo) {
    $stmt = $pdo->query("SELECT id, username, email, role, created_at FROM users ORDER BY created_at DESC");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

//Delete user and all their comments
function deleteUser($pdo, $userId) {
    try {
       // 1. Delete all comments belonging to user
        $stmt = $pdo->prepare("DELETE FROM comments WHERE userId = :userId");
        $stmt->execute(['userId' => $userId]);

        // 2.Delete user
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = :id");
        $stmt->execute(['id' => $userId]);

        return true;
    } catch (PDOException $e) {
        return false;
    }
}

// Add module
function addModule($pdo, $moduleName) {
    $stmt = $pdo->prepare("INSERT INTO modules (moduleName) VALUES (:moduleName)");
    return $stmt->execute(['moduleName' => $moduleName]);
}

// Delete module
function deleteModule($pdo, $moduleId) {
    try {
        $stmt = $pdo->prepare("DELETE FROM modules WHERE id = :id");
        return $stmt->execute(['id' => $moduleId]);
    } catch (PDOException $e) {
        return false; // If delete fails due to foreign key constraint (posts), return false
    }
}
// Check if contact form data is valid
function isValidContactForm($name, $email, $subject, $message): bool {
    return !empty($name) && !empty($email) && !empty($subject) && !empty($message);
}

function getUserById($pdo, $userId) {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = :id");
    $stmt->execute(['id' => $userId]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}
//Update user information
function updateUser($pdo, $userId, $username, $email, $role) {
    $stmt = $pdo->prepare("UPDATE users SET username = :username, email = :email, role = :role WHERE id = :id");
    return $stmt->execute([
        'username' => $username,
        'email' => $email,
        'role' => $role,
        'id' => $userId
    ]);
}


function addUser($pdo, $username, $email) {
    // Check for duplicate email
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM users WHERE email = :email');
    $stmt->execute(['email' => $email]);
    if ($stmt->fetchColumn() > 0) {
        throw new Exception("Email already exists.");
    }

    // Insert new user
    $stmt = $pdo->prepare('INSERT INTO users (username, email) VALUES (:username, :email)');
    $stmt->execute([
        'username' => $username,
        'email' => $email
    ]);
}

?>