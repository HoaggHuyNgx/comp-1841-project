<?php
// Session.php — phiên bản hợp nhất và không bị lỗi

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Functional style
function isLoggedIn(): bool {
    return isset($_SESSION['user_id']);
}

function requireLogin(): void {
    if (!isLoggedIn()) {
        header('Location: ../public/login.php');
        exit();
    }
}

function isAdmin(): bool {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

function requireAdmin(): void {
    if (!isAdmin()) {
        header('Location: ../public/login.php');
        exit();
    }
}

function getCurrentUsername(): string {
    return $_SESSION['username'] ?? 'Guest';
}

// Class-based style
class Session {
    public static function checkLogin() {
        if (!isset($_SESSION['user_id'])) {
            header('Location: ../login.php');
            exit();
        }
    }

    public static function login($userId) {
        $_SESSION['user_id'] = $userId;
    }

    public static function logout() {
        session_destroy();
        header('Location: ../login.php');
        exit();
    }
}
