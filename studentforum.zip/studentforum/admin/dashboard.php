<?php
require_once '../includes/DatabaseConnection.php';
require_once '../includes/Session.php';
require_once '../includes/Databasefunctions.php';

requireAdmin();

$title = "Admin Dashboard";

ob_start();
include '../templates/admin_dashboard.html.php';
$content = ob_get_clean();

include '../templates/admin_layout.html.php';
?>
