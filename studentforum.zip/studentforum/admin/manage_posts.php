<?php
require_once '../includes/DatabaseConnection.php';
require_once '../includes/Session.php';
require_once '../includes/Databasefunctions.php';

requireAdmin();

//Process and delete posts if requested
if (isset($_GET['delete'])) {
    $postId = (int) $_GET['delete'];

    if (deletePost($pdo, $postId)) {
        $success = "Post deleted successfully!";
    } else {
        $error = "Failed to delete post.";
    }
}

//Get a list of all posts (Admin shares getAllPosts)
$posts = getAllPosts($pdo);

//Load interface
$title = "Manage Posts";

ob_start();
include '../templates/manage_posts.html.php';
$content = ob_get_clean();
include '../templates/admin_layout.html.php';
?>
