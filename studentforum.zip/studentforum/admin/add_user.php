<?php
require_once '../includes/DatabaseConnection.php';
require_once '../includes/Session.php';
require_once '../includes/Databasefunctions.php';

Session::checkLogin();

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');

    if (empty($username) || empty($email)) {
        $error = 'Please fill in all fields.';
    } else {
        try {
            addUser($pdo, $username, $email);
            header('Location: manage_users.php');
            exit();
        } catch (Exception $e) {
            $error = $e->getMessage();
        }
    }
}

$title = 'Add New User';
ob_start();
include '../templates/add_user.html.php';
$content = ob_get_clean();

include '../templates/admin_layout.html.php';
