<?php
require_once '../includes/DatabaseConnection.php';
require_once '../includes/Session.php';
require_once '../includes/Databasefunctions.php';

requireAdmin();

// Add new module
if (isset($_POST['new_module_name'])) {
    $moduleName = trim($_POST['new_module_name']);
    if (!empty($moduleName)) {
        addModule($pdo, $moduleName);
        $success = "Module added successfully!";
    } else {
        $error = "Module name cannot be empty!";
    }
}

//Delete module
if (isset($_GET['delete'])) {
    $moduleId = (int) $_GET['delete'];
    deleteModule($pdo, $moduleId);
    $success = "Module deleted successfully!";
}

//Update module
if (isset($_POST['edit_module_id'], $_POST['edit_module_name'])) {
    $editId = (int) $_POST['edit_module_id'];
    $editName = trim($_POST['edit_module_name']);
    if (!empty($editName)) {
        updateModule($pdo, $editId, $editName);
        $success = "Module updated successfully!";
    } else {
        $error = "Module name cannot be empty!";
    }
}

//Get module list
$modules = getAllModules($pdo);

//Interface
$title = "Manage Modules";
ob_start();
include '../templates/manage_modules.html.php';
$content = ob_get_clean();
include '../templates/admin_layout.html.php';
?>
