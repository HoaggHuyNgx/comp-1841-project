<?php
require_once '../includes/DatabaseConnection.php';
require_once '../includes/Session.php';
require_once '../includes/Databasefunctions.php';

requireAdmin();

$title = "Manage Users";
//If admin presses Delete
if (isset($_GET['delete'])) {
    $userId = (int) $_GET['delete'];

    if (deleteUser($pdo, $userId)) {
        header("Location: manage_users.php");
        exit();
    } else {
        $error = "Failed to delete user.";
    }
}


//Process user deletion if admin clicks Delete
if (isset($_GET['delete'])) {
    $userId = (int) $_GET['delete'];
    deleteUser($pdo, $userId);
    header('Location: manage_users.php');
    exit();
}


//Get list of users
$users = getAllUsers($pdo);

ob_start();
include '../templates/manage_users.html.php';
$content = ob_get_clean();
include '../templates/admin_layout.html.php';
?>
