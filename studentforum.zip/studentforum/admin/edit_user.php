<?php
require_once '../includes/DatabaseConnection.php';
require_once '../includes/Session.php';
require_once '../includes/Databasefunctions.php';

requireAdmin();

$userId = $_GET['id'] ?? null;
if (!$userId) {
    header("Location: manage_users.php");
    exit();
}

$user = getUserById($pdo, $userId); // Viết thêm hàm getUserById nếu chưa có
if (!$user) {
    header("Location: manage_users.php");
    exit();
}

$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $role = $_POST['role'];

    if (empty($username) || empty($email)) {
        $errors[] = "Username and Email cannot be empty.";
    }

    if (empty($errors)) {
        if (updateUser($pdo, $userId, $username, $email, $role)) {
            $success = "User updated successfully.";
            $user = getUserById($pdo, $userId); // Refresh data
        } else {
            $errors[] = "Failed to update user.";
        }
    }
}

$title = "Edit User";
ob_start();
include '../templates/edit_user.html.php';
$content = ob_get_clean();
include '../templates/admin_layout.html.php';
?>
